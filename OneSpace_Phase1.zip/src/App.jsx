import React, { useEffect, useState } from "react";

const initialSpaces = [
  { id: 1, name: "Personal", icon: "bi-person", count: 8 },
  { id: 2, name: "College", icon: "bi-mortarboard", count: 12 },
  { id: 3, name: "Projects", icon: "bi-code-slash", count: 6 },
];

const nav = [
  ["Dashboard", "bi-grid-1x2-fill"],
  ["Needs Attention", "bi-exclamation-circle"],
  ["Today", "bi-calendar3"],
  ["Upcoming", "bi-calendar-week"],
  ["Ideas", "bi-lightbulb"],
];

function App() {
  const [dark, setDark] = useState(() => localStorage.getItem("onespace-theme") === "dark");
  const [active, setActive] = useState("Dashboard");
  const [showCapture, setShowCapture] = useState(false);
  const [showSpace, setShowSpace] = useState(false);
  const [spaces, setSpaces] = useState(initialSpaces);
  const [capture, setCapture] = useState("");
  const [spaceName, setSpaceName] = useState("");

  useEffect(() => {
    document.documentElement.setAttribute("data-bs-theme", dark ? "dark" : "light");
    localStorage.setItem("onespace-theme", dark ? "dark" : "light");
  }, [dark]);

  function addSpace(e) {
    e.preventDefault();
    if (!spaceName.trim()) return;
    setSpaces([...spaces, { id: Date.now(), name: spaceName.trim(), icon: "bi-folder", count: 0 }]);
    setSpaceName("");
    setShowSpace(false);
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><i className="bi bi-layers-fill"></i></div>
          <span>OneSpace</span>
        </div>

        <button className="quick-capture" onClick={() => setShowCapture(true)}>
          <i className="bi bi-plus-lg"></i> Quick Capture
        </button>

        <div className="nav-section">
          <div className="nav-label">WORKSPACE</div>
          {nav.map(([label, icon]) => (
            <button key={label} className={`side-link ${active === label ? "active" : ""}`} onClick={() => setActive(label)}>
              <i className={`bi ${icon}`}></i><span>{label}</span>
            </button>
          ))}
        </div>

        <div className="nav-section spaces-section">
          <div className="space-heading">
            <span className="nav-label mb-0">SPACES</span>
            <button className="icon-btn" onClick={() => setShowSpace(true)} title="Create space"><i className="bi bi-plus"></i></button>
          </div>
          {spaces.map(s => (
            <button key={s.id} className="side-link" onClick={() => setActive(s.name)}>
              <i className={`bi ${s.icon}`}></i><span>{s.name}</span><small>{s.count}</small>
            </button>
          ))}
        </div>

        <div className="sidebar-bottom">
          <button className="side-link"><i className="bi bi-gear"></i><span>Settings</span></button>
          <button className="side-link"><i className="bi bi-question-circle"></i><span>Help</span></button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">WEDNESDAY, AUGUST 26</div>
            <h1>{active === "Dashboard" ? "Good afternoon, Padmaj." : active}</h1>
          </div>
          <div className="top-actions">
            <button className="icon-btn" onClick={() => setDark(!dark)} title="Toggle theme">
              <i className={`bi ${dark ? "bi-sun" : "bi-moon"}`}></i>
            </button>
            <div className="avatar">PR</div>
          </div>
        </header>

        <section className="content">
          <div className="hero-row">
            <div>
              <h2>Everything in one place.</h2>
              <p>Keep track of what matters, what needs attention, and what's coming next.</p>
            </div>
            <button className="btn btn-dark rounded-pill px-4" onClick={() => setShowCapture(true)}>
              <i className="bi bi-plus-lg me-2"></i>Add something
            </button>
          </div>

          <div className="attention-card">
            <div className="attention-icon"><i className="bi bi-exclamation-lg"></i></div>
            <div className="flex-grow-1">
              <div className="card-kicker">NEEDS ATTENTION</div>
              <h3>Finish your FSD assignment</h3>
              <p>Due tomorrow · College</p>
            </div>
            <button className="btn btn-outline-secondary rounded-pill">Open</button>
          </div>

          <div className="section-head">
            <h3>Today</h3><button className="text-btn">View calendar <i className="bi bi-arrow-right"></i></button>
          </div>
          <div className="grid-2">
            <div className="panel">
              <div className="panel-title"><i className="bi bi-clock"></i> Schedule</div>
              <div className="timeline">
                <div><span>10:00</span><strong>Pattern Recognition practical</strong></div>
                <div><span>14:30</span><strong>Work on OneSpace</strong></div>
                <div><span>18:00</span><strong>Guitar practice</strong></div>
              </div>
            </div>
            <div className="panel">
              <div className="panel-title"><i className="bi bi-check2-circle"></i> Quick wins</div>
              {["Review today's notes", "Push project changes", "Plan tomorrow"].map(x => (
                <label className="check-row" key={x}><input type="checkbox"/><span>{x}</span></label>
              ))}
            </div>
          </div>

          <div className="section-head mt-4"><h3>Upcoming</h3><button className="text-btn">See all <i className="bi bi-arrow-right"></i></button></div>
          <div className="upcoming-grid">
            {[
              ["Aug 27","FSD Assignment","College","bi-file-earmark-text"],
              ["Aug 29","Project review","Projects","bi-code-square"],
              ["Sep 02","Semester planning","Personal","bi-calendar-check"]
            ].map(([date,title,space,icon]) => (
              <div className="upcoming-card" key={title}>
                <div className="date-box"><b>{date.split(" ")[1]}</b><small>{date.split(" ")[0]}</small></div>
                <div><i className={`bi ${icon} item-icon`}></i><h4>{title}</h4><p>{space}</p></div>
              </div>
            ))}
          </div>

          <div className="section-head mt-4"><h3>Ideas</h3><button className="text-btn" onClick={() => setActive("Ideas")}>View ideas <i className="bi bi-arrow-right"></i></button></div>
          <div className="idea-panel">
            <div className="idea-icon"><i className="bi bi-lightbulb"></i></div>
            <div><h4>Build a small Unreal Engine prototype</h4><p>Captured 2 hours ago · Projects</p></div>
            <button className="icon-btn ms-auto"><i className="bi bi-three-dots"></i></button>
          </div>
        </section>
      </main>

      {showCapture && <Modal title="Quick Capture" onClose={() => setShowCapture(false)}>
        <textarea className="form-control mb-3" rows="5" autoFocus placeholder="What's on your mind?" value={capture} onChange={e => setCapture(e.target.value)} />
        <div className="d-flex justify-content-end gap-2"><button className="btn btn-light" onClick={() => setShowCapture(false)}>Cancel</button><button className="btn btn-dark" onClick={() => {setCapture(""); setShowCapture(false)}}>Capture</button></div>
      </Modal>}

      {showSpace && <Modal title="Create Space" onClose={() => setShowSpace(false)}>
        <form onSubmit={addSpace}>
          <label className="form-label">Space name</label>
          <input className="form-control mb-3" autoFocus value={spaceName} onChange={e => setSpaceName(e.target.value)} placeholder="e.g. Career" />
          <div className="d-flex justify-content-end gap-2"><button type="button" className="btn btn-light" onClick={() => setShowSpace(false)}>Cancel</button><button className="btn btn-dark">Create</button></div>
        </form>
      </Modal>}
    </div>
  );
}

function Modal({title,onClose,children}) {
  return <div className="modal-backdrop-custom" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <div className="modal-card">
      <div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose}><i className="bi bi-x-lg"></i></button></div>
      {children}
    </div>
  </div>
}

export default App;
